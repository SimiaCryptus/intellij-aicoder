import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class SupportAliasSlackBotApplication

fun main(args: Array<String>) {
    SpringApplication.run(SupportAliasSlackBotApplication::class.java, *args)
}

// TODO: Implement Slack bot and database interaction logic

/*** README.md ***/

# SupportAliasSlackBot

A Kotlin-based Slack bot to monitor a support alias. All requests tagging an alias are recorded in a database. When requests are tagged with a specific label, the bot will send a message to a slack channel.

## Requirements

- Kotlin
- Spring
- Gradle

## Installation

1. Clone the repository
2. Run `./gradlew build` to build the project
3. Run `./gradlew bootRun` to start the application

## Usage

- Configure your Slack bot and database settings in `application.properties`
- Deploy the application to your desired environment
- Test the bot and database interactions

## License

[MIT](https://choosealicense.com/licenses/mit/)