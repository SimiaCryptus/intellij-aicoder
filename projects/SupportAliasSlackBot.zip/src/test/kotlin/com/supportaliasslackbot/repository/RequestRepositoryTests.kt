import com.supportaliasslackbot.repository.RequestRepository
import com.supportaliasslackbot.model.SlackRequest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest

@DataJpaTest
class RequestRepositoryTests @Autowired constructor(
    private val requestRepository: RequestRepository
) {

    @Test
    fun saveTest() {
        val request = SlackRequest(
            id = 0L,
            text = "Test request",
            user = "U12345",
            timestamp = "1629459200"
        )

        val savedRequest = requestRepository.save(request)

        assertEquals(request.text, savedRequest.text)
        assertEquals(request.user, savedRequest.user)
        assertEquals(request.timestamp, savedRequest.timestamp)
    }
}