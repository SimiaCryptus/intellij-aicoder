import com.supportaliasslackbot.service.RequestService
import org.springframework.stereotype.Component

@Component
class SlackRequestListener(private val requestService: RequestService) {

    fun onMessage(request: SlackRequest) {
        // TODO: Implement onMessage method
    }
}

import com.supportaliasslackbot.listener.SlackRequestListener
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.jupiter.MockitoExtension

@ExtendWith(MockitoExtension::class)
class SlackRequestListenerTests {

    @InjectMocks
    private lateinit var slackRequestListener: SlackRequestListener

    @Mock
    private lateinit var requestService: RequestService

    @Test
    fun onMessageTest() {
        // TODO: Implement test for onMessage method
    }
}