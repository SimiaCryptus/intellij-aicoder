import com.supportaliasslackbot.repository.RequestRepository
import com.supportaliasslackbot.model.SlackRequest

@Service
class RequestService(private val requestRepository: RequestRepository) {

    fun saveRequest(request: SlackRequest) {
        requestRepository.save(request)
    }

    fun sendMessageToChannel(request: SlackRequest) {
        // Implementation for sending a message to a slack channel
    }
}

import com.supportaliasslackbot.service.RequestService
import com.supportaliasslackbot.model.SlackRequest

@Component
class SlackRequestListener(private val requestService: RequestService) {

    fun onMessage(request: SlackRequest) {
        requestService.saveRequest(request)
        if (request.label == "specificLabel") {
            requestService.sendMessageToChannel(request)
        }
    }
}