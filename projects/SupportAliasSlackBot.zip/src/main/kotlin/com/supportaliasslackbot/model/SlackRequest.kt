package com.supportaliasslackbot.model

import java.time.LocalDateTime

data class SlackRequest(
    val id: Long,
    val supportAlias: String,
    val label: String,
    val timestamp: LocalDateTime,
    val message: String
)