package com.supportaliasslackbot.repository

import com.supportaliasslackbot.model.SlackRequest
import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Repository

@Repository
interface RequestRepository : CrudRepository<SlackRequest, Long> {

    fun save(request: SlackRequest): SlackRequest

}