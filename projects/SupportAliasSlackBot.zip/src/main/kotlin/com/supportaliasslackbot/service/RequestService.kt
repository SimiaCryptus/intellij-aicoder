package com.supportaliasslackbot.service

import com.supportaliasslackbot.repository.RequestRepository
import com.supportaliasslackbot.model.SlackRequest

/**
 * The service class for handling incoming requests and interacting with the database.
 */
class RequestService(private val requestRepository: RequestRepository) {

    /**
     * Save the incoming request in the database.
     *
     * @param request The incoming SlackRequest to be saved.
     */
    fun saveRequest(request: SlackRequest) {
        requestRepository.save(request)
    }

    /**
     * Send a message to the designated slack channel.
     *
     * @param request The incoming SlackRequest containing the message to be sent.
     */
    fun sendMessageToChannel(request: SlackRequest) {
        // TODO: Implement the logic for sending a message to the slack channel.
    }
}