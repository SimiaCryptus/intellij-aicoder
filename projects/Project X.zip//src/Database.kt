class Database {

    fun createDatabase() {
        // implementation
    }

    fun addQuestion(question: String, response: String) {
        // implementation
    }

    fun getQuestionResponse(question: String) {
        // implementation
    }
}