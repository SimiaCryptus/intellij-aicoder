//TODO: Implement Project X

import NaturalLanguageProcessor
import Database

class ProjectX {
    //TODO: Implement project code
    
    fun testDetectCommonQuestion() {
        //TODO: Implement functional test code
    }
}