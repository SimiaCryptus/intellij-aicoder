package com.example.infinitescrollingnewsfeed.model

import java.time.LocalDateTime

/**
 * Data class representing a single news feed item.
 */
data class NewsFeedItem(
    val id: Long,
    val title: String,
    val content: String,
    val timestamp: LocalDateTime
)