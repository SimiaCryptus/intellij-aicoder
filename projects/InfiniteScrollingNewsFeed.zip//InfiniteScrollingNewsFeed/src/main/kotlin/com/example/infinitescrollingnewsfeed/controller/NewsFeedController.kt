import com.example.infinitescrollingnewsfeed.repository.NewsFeedRepository
import com.example.infinitescrollingnewsfeed.model.NewsFeedItem
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
class NewsFeedController @Autowired constructor(private val newsFeedService: NewsFeedService) {

    @GetMapping("/newsfeed")
    fun getNewsFeedItems(
        @RequestParam(value = "page", defaultValue = "0") page: Int,
        @RequestParam(value = "pageSize", defaultValue = "10") pageSize: Int
    ): ResponseEntity<List<NewsFeedItem>> {
        val newsFeedItems = newsFeedService.getNewsFeedItems(page, pageSize)
        return ResponseEntity.ok(newsFeedItems)
    }
}

import org.springframework.stereotype.Service

@Service
class NewsFeedService @Autowired constructor(private val newsFeedRepository: NewsFeedRepository) {

    fun getNewsFeedItems(page: Int, pageSize: Int): List<NewsFeedItem> {
        return newsFeedRepository.findNewsFeedItems(page, pageSize)
    }
}