package com.example.infinitescrollingnewsfeed.repository

import com.example.infinitescrollingnewsfeed.model.NewsFeedItem
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface NewsFeedRepository : JpaRepository<NewsFeedItem, Long> {

    fun findNewsFeedItemsByPage(page: Int, pageSize: Int): List<NewsFeedItem> {
        val pageable: Pageable = PageRequest.of(page, pageSize)
        return findAll(pageable).content
    }
}