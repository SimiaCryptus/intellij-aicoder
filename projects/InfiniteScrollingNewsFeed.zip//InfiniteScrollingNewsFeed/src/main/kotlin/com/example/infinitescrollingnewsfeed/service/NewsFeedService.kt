package com.example.infinitescrollingnewsfeed.service

import com.example.infinitescrollingnewsfeed.model.NewsFeedItem
import com.example.infinitescrollingnewsfeed.repository.NewsFeedRepository
import org.springframework.stereotype.Service

@Service
class NewsFeedService(private val newsFeedRepository: NewsFeedRepository) {

    fun getNewsFeedItems(page: Int, pageSize: Int): List<NewsFeedItem> {
        return newsFeedRepository.findNewsFeedItemsByPage(page, pageSize)
    }
}