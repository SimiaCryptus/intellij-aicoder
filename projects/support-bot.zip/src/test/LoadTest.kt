import kotlinx.coroutines.*
import com.slack.api.bolt.App
import com.slack.api.bolt.jetty.SlackAppServer

fun main() {
    val app = App()
    app.command("/hello") { req, ctx ->
        ctx.ack("Hello, world!")
    }
    val server = SlackAppServer(app, System.getenv("SLACK_APP_TOKEN"))
    runBlocking {
        launch {
            server.start()
        }
    }
}