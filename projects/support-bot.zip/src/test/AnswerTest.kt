// Support Bot project

import com.slack.api.bolt.App
import com.slack.api.bolt.jetty.SlackAppServer
import kotlinx.coroutines.runBlocking

fun main() {
	val appToken = System.getenv("SLACK_APP_TOKEN")
	val botToken = System.getenv("SLACK_BOT_TOKEN")
	val signingSecret = System.getenv("SLACK_SIGNING_SECRET")
	val app = App().apply {
		this.use(SlackAppServer.create(this, signingSecret).start())
		this.event("app_mention") { event, _ ->
			runBlocking {
				val message = event.message
				if (message != null && message.text != null) {
					val response = Answer.findMatch(message.text)
					if (response != null) {
						val client = this.slack().methods(botToken)
						client.chatPostMessage {
							it.channel(event.channel)
							it.threadTs(event.threadTs ?: event.ts)
							it.text(response)
						}
					}
				}
			}
		}
	}
	app.start()
}

/**
 * Answer class
 * Contains logic for finding and returning a response to a given message
 */
class Answer {
	companion object {
		private val answers = mapOf(
			"Hi" to "Hello, how can I help you?",
			"Help" to "What do you need help with?",
			"Thanks" to "You're welcome!"
		)

		/**
		 * Finds a matching response for a given message
		 * Returns null if no match is found
		 */
		fun findMatch(message: String): String? {
			val words = message.split(" ")
			for (word in words) {
				if (answers.containsKey(word)) {
					return answers[word]
				}
			}
			return null
		}
	}
}

/**
 * Unit tests for the Answer class
 */
class AnswerTest {
	@Test
	fun testMatches() {
		assertEquals("Hello, how can I help you?", Answer.findMatch("Hi"))
		assertEquals("What do you need help with?", Answer.findMatch("Help me"))
		assertEquals(null, Answer.findMatch("Howdy"))
		assertEquals("You're welcome!", Answer.findMatch("Thanks"))
	}
}