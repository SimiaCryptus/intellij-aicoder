import com.slack.api.bolt.App
import com.slack.api.bolt.jetty.SlackAppServer
import kotlinx.coroutines.runBlocking

fun main() {
    val app = App()

    app.command("/hello") { req, ctx ->
        val channel = req.payload.channelId
        val user = req.payload.userId
        runBlocking {
            ctx.client().chatPostMessage { it
                .channel(channel)
                .text("Hello, <@$user>!")
            }
        }
        ctx.ack()
    }

    val server = SlackAppServer(app, System.getenv("SLACK_APP_PORT").toInt())
    server.start()
}