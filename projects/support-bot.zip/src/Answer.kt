import com.slack.api.bolt.App
import com.slack.api.bolt.jetty.SlackAppServer
import com.slack.api.model.event.MessageEvent
import com.slack.api.model.Message

class Answer(val text: String, val keywords: List<String>) {
    fun matches(message: Message): Boolean {
        return keywords.any { keyword -> message.text.contains(keyword, ignoreCase = true) }
    }
}

class SupportBot {
    private val answers = listOf(
        Answer("Please try clearing your cache and cookies", listOf("cache", "cookies")),
        Answer("Have you tried turning it off and on again?", listOf("restart", "reboot"))
    )

    fun start(appToken: String, botToken: String) {
        val app = App().asBot(botToken)
        app.event(MessageEvent::class.java) { event, ctx ->
            val message = event.getBotMessage() ?: return@event
            val answer = answers.firstOrNull { it.matches(message) } ?: return@event
            ctx.say(answer.text)
        }
        val server = SlackAppServer(app, appToken)
        server.start()
    }
}