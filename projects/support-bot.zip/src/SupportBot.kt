import com.slack.api.bolt.App
import com.slack.api.bolt.jetty.SlackAppServer
import kotlinx.coroutines.runBlocking

fun main() {
    val app = App()

    app.command("/hello") { req, ctx ->
        val message = "Hello, ${req.payload.userName}!"
        ctx.respond(message)
    }

    app.event(AppMentionEvent::class.java) { event, ctx ->
        val message = "Hi there!"
        val channelId = event.event.channel
        runBlocking {
            ctx.client().chatPostMessage { req ->
                req.channel(channelId).text(message)
            }
        }
        ctx.ack()
    }

    val server = SlackAppServer(app, 8080)
    server.start()
}