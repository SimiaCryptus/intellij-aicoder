// Generated code for my-project

import org.jetbrains.kotlin.kotlin-test

// Test class for the QuestionRecognizer class
class QuestionRecognizerTest {

    fun testRecognizeQuestion() {
        // Your test code here
    }
}