/* Generated code for my-project */

import com.slack.api.bolt.App
import com.slack.api.bolt.jetty.SlackAppServer
import com.slack.api.bolt.response.ResponseTypes
import com.slack.api.methods.SlackApiException
import com.slack.api.model.event.MessageEvent
import com.slack.api.model.view.View
import edu.stanford.nlp.simple.*
import java.util.concurrent.TimeUnit

class Main {

    private val botToken: String = "YOUR_BOT_TOKEN"
    private val channelId: String = "YOUR_CHANNEL_ID"
    private val responseRateLimit: Long = 10L
    private val commonQuestions: List<String> = listOf("What is the status of my request?", "Can I get a refund?", "How do I change my password?")

    private lateinit var app: App
    private lateinit var server: SlackAppServer
    private var stopRequested: Boolean = false

    fun start() {
        app = App()
        app.command("/help") { req, ctx ->
            ctx.respond("I'm here to help you! Ask me anything and I'll do my best to assist you.")
        }
        app.message { req, ctx ->
            val message = req.event as MessageEvent
            if (message.channel == channelId) {
                if (recognizeQuestion(message) != null) {
                    if (Math.random() * 100 < responseRateLimit) {
                        val response = getCommonQuestions().shuffled().firstOrNull()
                        if (response != null) {
                            ctx.respond(ResponseTypes.inChannel(response))
                        }
                    }
                }
            }
            ctx.ack()
        }
        app.viewSubmission("/feedback") { req, ctx ->
            ctx.respond("Thanks for your feedback!")
        }
        server = SlackAppServer(app, botToken)
        server.start()
    }

    fun stop() {
        stopRequested = true
        server.stop()
    }

    fun handleMessage(message: MessageEvent) : Boolean {
        if (message.channel == channelId) {
            if (recognizeQuestion(message) != null) {
                if (Math.random() * 100 < responseRateLimit) {
                    val response = getCommonQuestions().shuffled().firstOrNull()
                    if (response != null) {
                        app.client().chatPostMessage { it
                            .channel(message.channel)
                            .text(response)
                        }
                        return true
                    }
                }
            }
        }
        return false
    }

    fun recognizeQuestion(message: MessageEvent) : String? {
        val pipeline = StanfordCoreNLP("annotators", "tokenize,ssplit,pos,lemma,ner,parse,depparse,coref,kbp,quote,sentiment");
        val doc = CoreDocument(message.text)
        pipeline.annotate(doc)
        val sentences = doc.sentences()
        for (sentence in sentences) {
            for (token in sentence.tokens()) {
                if (token.ner() == "O") {
                    if (token.originalText().endsWith("?") || token.originalText().endsWith("?")) {
                        return token.originalText()
                    }
                }
            }
        }
        return null
    }

    fun getCommonQuestions() : List<String> {
        return commonQuestions
    }

}