import com.slack.api.Slack
import com.slack.api.methods.MethodsClient
import com.slack.api.methods.request.chat.ChatPostMessageRequest
import com.slack.api.model.Message
import com.slack.api.model.event.MessageEvent


class SlackBot(botToken: String, channelId: String) {

    private val slack: Slack = Slack.getInstance()
    private val methods: MethodsClient = slack.methods(botToken)
    private val channel: String = channelId

    fun sendMessage(message: String) {
        val request = ChatPostMessageRequest.builder().channel(channel).text(message).build()
        methods.chatPostMessage(request)
    }

    fun getChannelHistory(): List<MessageEvent> {
        val response = methods.conversationsHistory { req -> req.channel(channel) }
        return response.messages.filterIsInstance<MessageEvent>()
    }
}