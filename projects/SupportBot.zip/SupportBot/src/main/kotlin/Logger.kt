import kotlinx.coroutines.*
import com.slack.api.Slack
import com.slack.api.methods.SlackApiException
import com.slack.api.model.event.MessageEvent
import com.slack.api.model.message.Message
import java.time.LocalDateTime


class Logger {
    private val slack = Slack.getInstance()
    private val coroutineScope = CoroutineScope(Dispatchers.IO)
    
    fun logInquiry(message: MessageEvent) {
        coroutineScope.launch {
            try {
                val channel = message.channel
                val user = message.user
                val text = message.text
                slack.methods().chatPostMessage {
                    it.channel(channel)
                    it.text("Inquiry from $user at ${LocalDateTime.now()} : $text")
                }.execute()
            } catch (e: SlackApiException) {
                e.printStackTrace()
            }
        }
    }
    
    fun logResponse(question: String, response: String) {
        coroutineScope.launch {
            try {
                slack.methods().chatPostMessage {
                    it.channel("support-bot-logs")
                    it.text("Question: $question | Response: $response")
                }.execute()
            } catch (e: SlackApiException) {
                e.printStackTrace()
            }
        }
    }
}