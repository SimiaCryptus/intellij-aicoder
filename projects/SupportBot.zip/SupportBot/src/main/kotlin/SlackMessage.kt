package SupportBot.src.main.kotlin

class SlackMessage(val text: String, val sender: String, val timestamp: Long)
