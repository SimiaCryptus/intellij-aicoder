// This code is just an example

import kotlinx.coroutines.*
import com.slack.api.bolt.App
import com.slack.api.bolt.jetty.SlackAppServer

fun main() {
    val app = App()
    app.command("/hello") { req, ctx ->
        ctx.ack("Hello, ${req.payload.userName}!")
    }
    val server = SlackAppServer(app, 3000)
    server.start()
}