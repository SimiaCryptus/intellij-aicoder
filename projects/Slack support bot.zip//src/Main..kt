import nlp
import database
import slack

class Main {
    private val database: Database = Database()
    private val slack: Slack = Slack()
    private val nlp: Nlp = Nlp()

    fun start() {
        // Start monitoring support alias
        slack.monitor("support")
    }

    fun stop() {
        // Stop monitoring support alias
        slack.stopMonitoring("support")
    }

    // Automatically respond to common questions
    private fun autoRespond(question: String) {
        val response = nlp.getResponse(question)
        if (response != null) {
            slack.sendMessage(response)
        }
    }
}