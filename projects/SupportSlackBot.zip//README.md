import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import com.slack.api.bolt.App
import com.slack.api.bolt.jetty.SlackAppServer
import org.springframework.context.annotation.Bean
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.repository.CrudRepository
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id

@SpringBootApplication
class SupportSlackBotApplication

fun main(args: Array<String>) {
    runApplication<SupportSlackBotApplication>(*args)
}

@Entity
data class Request(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long? = null,
    val alias: String,
    val label: String
)

interface RequestRepository : JpaRepository<Request, Long>

@Bean
fun app(requestRepository: RequestRepository): App {
    val app = App()

    app.event(ReactionAddedEvent::class.java) { payload, ctx ->
        val reaction = payload.event.reaction
        val alias = payload.event.itemUser

        if (reaction == "specific_label") {
            requestRepository.save(Request(alias = alias, label = reaction))
            ctx.say("A request with the specific label has been recorded.")
        }
    }

    return app
}

@Bean
fun server(app: App): SlackAppServer {
    return SlackAppServer(app)
}