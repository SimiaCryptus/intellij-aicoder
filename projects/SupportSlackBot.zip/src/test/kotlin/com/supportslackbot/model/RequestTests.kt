import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.beans.factory.annotation.Autowired
import com.supportslackbot.model.Request
import com.supportslackbot.repository.RequestRepository

@SpringBootTest
class RequestTests(@Autowired val requestRepository: RequestRepository) {

    @Test
    fun testRequestCreation() {
        val request = Request(
            id = 1L,
            author = "John Doe",
            content = "This is a sample request",
            label = "urgent"
        )

        assert(request.id == 1L)
        assert(request.author == "John Doe")
        assert(request.content == "This is a sample request")
        assert(request.label == "urgent")
    }

    @Test
    fun testRequestDataStorageAndRetrieval() {
        val request = Request(
            id = 2L,
            author = "Jane Doe",
            content = "Another sample request",
            label = "normal"
        )

        requestRepository.save(request)

        val retrievedRequest = requestRepository.findById(2L).orElse(null)
        assert(retrievedRequest != null)
        assert(retrievedRequest?.id == 2L)
        assert(retrievedRequest?.author == "Jane Doe")
        assert(retrievedRequest?.content == "Another sample request")
        assert(retrievedRequest?.label == "normal")
    }
}