import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface RequestRepository : JpaRepository<Request, Long> {

    fun save(request: Request): Request

    fun findAll(): List<Request>

    fun findByAlias(alias: String): List<Request>

    fun findByLabel(label: String): List<Request>

}