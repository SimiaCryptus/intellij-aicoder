package com.supportslackbot

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

/**
 * SupportSlackBot application is a Slack bot to monitor a support alias. All requests tagging an alias are
 * recorded in a database. When requests are tagged with a specific label, the bot will send a message to a
 * slack channel.
 *
 * @author Your Name
 */
@SpringBootApplication
class SupportSlackBotApplication

/**
 * Main entry point of the SupportSlackBot application.
 *
 * @param args command line arguments
 */
fun main(args: Array<String>) {
    runApplication<SupportSlackBotApplication>(*args)
}