package com.supportslackbot.service

import com.slack.api.Slack
import com.slack.api.model.event.MessageEvent
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Service
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id

@SpringBootApplication
class SupportSlackBotApplication

fun main(args: Array<String>) {
    runApplication<SupportSlackBotApplication>(*args)
}

@Service
class SupportSlackBotService @Autowired constructor(
    private val requestRepository: RequestRepository,
    private val slack: Slack
) {

    fun monitorSupportAlias() {
        val settings = slack.methods().api.test().execute().needed
        // Implement monitoring logic here
    }

    fun recordTaggedRequest(request: Request) {
        requestRepository.save(request)
    }

    fun sendMessageToSlackChannel(request: Request) {
        // Implement Slack message sending logic here
    }
}

@Entity
data class Request(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long? = null,
    val text: String,
    val user: String,
    val timestamp: String
)

interface RequestRepository : JpaRepository<Request, Long>

@Bean
fun slack() = Slack.getInstance()